var files =
[
    [ "qpathedit.cpp", "qpathedit_8cpp_source.html", null ],
    [ "qpathedit.h", "qpathedit_8h_source.html", null ]
];