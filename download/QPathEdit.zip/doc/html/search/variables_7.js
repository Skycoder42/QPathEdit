var searchData=
[
  ['handle',['HANDLE',['http://doc.qt.io/qt-5/qt.html#HANDLE-typedef',0,'Qt']]]
];
