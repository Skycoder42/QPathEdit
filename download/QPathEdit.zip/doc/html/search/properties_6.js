var searchData=
[
  ['geometry',['geometry',['http://doc.qt.io/qt-5/qscreen.html#geometry-prop',0,'QScreen::geometry()'],['http://doc.qt.io/qt-5/qgraphicswidget.html#geometry-prop',0,'QGraphicsWidget::geometry()'],['http://doc.qt.io/qt-5/qwidget.html#geometry-prop',0,'QWidget::geometry()']]],
  ['gesturecancelpolicy',['gestureCancelPolicy',['http://doc.qt.io/qt-5/qgesture.html#gestureCancelPolicy-prop',0,'QGesture']]],
  ['gesturetype',['gestureType',['http://doc.qt.io/qt-5/qgesture.html#gestureType-prop',0,'QGesture']]],
  ['globalrestorepolicy',['globalRestorePolicy',['http://doc.qt.io/qt-5/qstatemachine.html#globalRestorePolicy-prop',0,'QStateMachine']]],
  ['globalstrut',['globalStrut',['http://doc.qt.io/qt-5/qapplication.html#globalStrut-prop',0,'QApplication']]],
  ['gridsize',['gridSize',['http://doc.qt.io/qt-5/qlistview.html#gridSize-prop',0,'QListView']]],
  ['gridstyle',['gridStyle',['http://doc.qt.io/qt-5/qtableview.html#gridStyle-prop',0,'QTableView']]],
  ['gridvisible',['gridVisible',['http://doc.qt.io/qt-5/qcalendarwidget.html#gridVisible-prop',0,'QCalendarWidget']]]
];
