var searchData=
[
  ['selection',['Selection',['http://doc.qt.io/qt-5/qabstracttextdocumentlayout-selection.html',0,'QAbstractTextDocumentLayout']]],
  ['sequence',['Sequence',['http://doc.qt.io/qt-5/qbluetoothserviceinfo-sequence.html',0,'QBluetoothServiceInfo']]],
  ['signalevent',['SignalEvent',['http://doc.qt.io/qt-5/qstatemachine-signalevent.html',0,'QStateMachine']]],
  ['state',['State',['http://doc.qt.io/qt-5/qaccessible-state.html',0,'QAccessible']]]
];
