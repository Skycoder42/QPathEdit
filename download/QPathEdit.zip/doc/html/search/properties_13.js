var searchData=
[
  ['undoavailable',['undoAvailable',['http://doc.qt.io/qt-5/qlineedit.html#undoAvailable-prop',0,'QLineEdit']]],
  ['undolimit',['undoLimit',['http://doc.qt.io/qt-5/qundostack.html#undoLimit-prop',0,'QUndoStack']]],
  ['undoredoenabled',['undoRedoEnabled',['http://doc.qt.io/qt-5/qtextdocument.html#undoRedoEnabled-prop',0,'QTextDocument::undoRedoEnabled()'],['http://doc.qt.io/qt-5/qplaintextedit.html#undoRedoEnabled-prop',0,'QPlainTextEdit::undoRedoEnabled()'],['http://doc.qt.io/qt-5/qtextbrowser.html#undoRedoEnabled-prop',0,'QTextBrowser::undoRedoEnabled()'],['http://doc.qt.io/qt-5/qtextedit.html#undoRedoEnabled-prop',0,'QTextEdit::undoRedoEnabled()']]],
  ['unifiedtitleandtoolbaronmac',['unifiedTitleAndToolBarOnMac',['http://doc.qt.io/qt-5/qmainwindow.html#unifiedTitleAndToolBarOnMac-prop',0,'QMainWindow']]],
  ['uniformitemsizes',['uniformItemSizes',['http://doc.qt.io/qt-5/qlistview.html#uniformItemSizes-prop',0,'QListView']]],
  ['uniformrowheights',['uniformRowHeights',['http://doc.qt.io/qt-5/qtreeview.html#uniformRowHeights-prop',0,'QTreeView']]],
  ['updateinterval',['updateInterval',['http://doc.qt.io/qt-5/qtimeline.html#updateInterval-prop',0,'QTimeLine::updateInterval()'],['http://doc.qt.io/qt-5/qgeopositioninfosource.html#updateInterval-prop',0,'QGeoPositionInfoSource::updateInterval()'],['http://doc.qt.io/qt-5/qgeosatelliteinfosource.html#updateInterval-prop',0,'QGeoSatelliteInfoSource::updateInterval()']]],
  ['updatesenabled',['updatesEnabled',['http://doc.qt.io/qt-5/qwidget.html#updatesEnabled-prop',0,'QWidget']]],
  ['url',['url',['http://doc.qt.io/qt-5/qqmlcomponent.html#url-prop',0,'QQmlComponent::url()'],['http://doc.qt.io/qt-5/qquickitemgrabresult.html#url-prop',0,'QQuickItemGrabResult::url()'],['http://doc.qt.io/qt-5/qwebenginepage.html#url-prop',0,'QWebEnginePage::url()'],['http://doc.qt.io/qt-5/qwebengineview.html#url-prop',0,'QWebEngineView::url()']]],
  ['usecompleter',['useCompleter',['../class_q_path_edit.html#a8eef119413965cade66069691c4008e4',1,'QPathEdit']]],
  ['usedesignmetrics',['useDesignMetrics',['http://doc.qt.io/qt-5/qtextdocument.html#useDesignMetrics-prop',0,'QTextDocument']]],
  ['userorientation',['userOrientation',['http://doc.qt.io/qt-5/qsensor.html#userOrientation-prop',0,'QSensor']]],
  ['usertlextensions',['useRtlExtensions',['http://doc.qt.io/qt-5/qstylehints.html#useRtlExtensions-prop',0,'QStyleHints']]],
  ['usesscrollbuttons',['usesScrollButtons',['http://doc.qt.io/qt-5/qtabbar.html#usesScrollButtons-prop',0,'QTabBar::usesScrollButtons()'],['http://doc.qt.io/qt-5/qtabwidget.html#usesScrollButtons-prop',0,'QTabWidget::usesScrollButtons()']]]
];
