var searchData=
[
  ['formatrange',['FormatRange',['http://doc.qt.io/qt-5/qtextlayout-formatrange.html',0,'QTextLayout']]]
];
