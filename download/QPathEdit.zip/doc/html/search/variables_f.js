var searchData=
[
  ['rangeaccessflags',['RangeAccessFlags',['http://doc.qt.io/qt-5/qopenglbuffer.html#RangeAccessFlag-enum',0,'QOpenGLBuffer']]],
  ['rawheader',['RawHeader',['http://doc.qt.io/qt-5/qnetworkcachemetadata.html#RawHeader-typedef',0,'QNetworkCacheMetaData']]],
  ['rawheaderlist',['RawHeaderList',['http://doc.qt.io/qt-5/qnetworkcachemetadata.html#RawHeaderList-typedef',0,'QNetworkCacheMetaData']]],
  ['rawheaderpair',['RawHeaderPair',['http://doc.qt.io/qt-5/qnetworkreply.html#RawHeaderPair-typedef',0,'QNetworkReply']]],
  ['readfunc',['ReadFunc',['http://doc.qt.io/qt-5/qsettings.html#ReadFunc-typedef',0,'QSettings']]],
  ['reduceoptions',['ReduceOptions',['http://doc.qt.io/qt-5/qtconcurrent.html#ReduceOption-enum',0,'QtConcurrent']]],
  ['reference',['reference',['http://doc.qt.io/qt-5/qjsonarray.html#reference-typedef',0,'QJsonArray::reference()'],['http://doc.qt.io/qt-5/qfuture-const-iterator.html#reference-typedef',0,'QFuture::const_iterator::reference()'],['http://doc.qt.io/qt-5/qlinkedlist.html#reference-typedef',0,'QLinkedList::reference()'],['http://doc.qt.io/qt-5/qlist.html#reference-typedef',0,'QList::reference()'],['http://doc.qt.io/qt-5/qset.html#reference-typedef',0,'QSet::reference()'],['http://doc.qt.io/qt-5/qstring.html#reference-typedef',0,'QString::reference()'],['http://doc.qt.io/qt-5/qvarlengtharray.html#reference-typedef',0,'QVarLengthArray::reference()'],['http://doc.qt.io/qt-5/qvector.html#reference-typedef',0,'QVector::reference()']]],
  ['relation',['Relation',['http://doc.qt.io/qt-5/qaccessible.html#RelationFlag-enum',0,'QAccessible']]],
  ['renderflags',['RenderFlags',['http://doc.qt.io/qt-5/qtextitem.html#RenderFlag-enum',0,'QTextItem::RenderFlags()'],['http://doc.qt.io/qt-5/qwidget.html#RenderFlag-enum',0,'QWidget::RenderFlags()']]],
  ['renderhints',['RenderHints',['http://doc.qt.io/qt-5/qpainter.html#RenderHint-enum',0,'QPainter']]],
  ['result',['Result',['http://doc.qt.io/qt-5/qgesturerecognizer.html#ResultFlag-enum',0,'QGestureRecognizer']]],
  ['routeoptimizations',['RouteOptimizations',['http://doc.qt.io/qt-5/qgeorouterequest.html#RouteOptimization-enum',0,'QGeoRouteRequest']]],
  ['routingfeatures',['RoutingFeatures',['http://doc.qt.io/qt-5/qgeoserviceprovider.html#RoutingFeature-enum',0,'QGeoServiceProvider']]]
];
