var searchData=
[
  ['unhandledexception',['UnhandledException',['http://doc.qt.io/qt-5/qtconcurrent-obsolete.html#UnhandledException-typedef',0,'QtConcurrent']]],
  ['usagepolicies',['UsagePolicies',['http://doc.qt.io/qt-5/qnetworksession.html#UsagePolicy-enum',0,'QNetworkSession']]],
  ['userinputresolutionoptions',['UserInputResolutionOptions',['http://doc.qt.io/qt-5/qurl.html#UserInputResolutionOption-enum',0,'QUrl']]]
];
