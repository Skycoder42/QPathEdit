var searchData=
[
  ['offsetdata',['OffsetData',['http://doc.qt.io/qt-5/qtimezone-offsetdata.html',0,'QTimeZone']]]
];
