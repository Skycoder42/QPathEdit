var searchData=
[
  ['quitlockenabled',['quitLockEnabled',['http://doc.qt.io/qt-5/qcoreapplication.html#quitLockEnabled-prop',0,'QCoreApplication']]],
  ['quitonlastwindowclosed',['quitOnLastWindowClosed',['http://doc.qt.io/qt-5/qguiapplication.html#quitOnLastWindowClosed-prop',0,'QGuiApplication']]]
];
