README:

Usage:
To use the classes, you can either:
 - Copy header and sourcefile into your project, and add CONFIG += C++11 to your project file
 - place header, source and .pri anywhere, and include the pri-file to your project. Add the line "include(<path_to_folder>/QPathEdit.pri)"
 
Designer Plugin:
To install the plugin, you need to copy the right file from the zip-package to the QtCreators designer plugin path. Inside the designerplugin folder,
there are a number of subfolders for operating systems I've created the plugin for. If yours is not present, you need to compile the plugin yourself.
Copy file (for example qpatheditplugin.dll) into QtCreators path. The default path would be <path_to_qt>/Tools/QtCreator/bin/plugins/designer for windows
and unix and <qt_creator_bundle>/contents/plugins/designer for mac. After restarting the creator, navigate to the designer and to
Tools > Form Editor > About Qt Designer Plugins. The plugin should appear there. You can find it inside the "Input Widgets" Section.
For more details, check Adding Qt Designer Plugins.

Documentation:
All downloads contain either the documentation or a doxygen-file to create it.
Documentation includes the html, and a file called "QPathEditHelp.qch". This file can be added to QtAssistant, the include the documentation
into QtCreator (You will be able to access the documentation like the normal Qt-Documentation).
To do so open Tools > Settings... > Help and navigate to the "Documentation" tab. Click "Add" to add the .qch-file, and thats it!