var annotated =
[
    [ "QPathEdit", "class_q_path_edit.html", "class_q_path_edit" ]
];