var searchData=
[
  ['name',['name',['http://doc.qt.io/qt-5/qscreen.html#name-prop',0,'QScreen::name()'],['http://doc.qt.io/qt-5/qdnslookup.html#name-prop',0,'QDnsLookup::name()']]],
  ['namefilterdetailsvisible',['nameFilterDetailsVisible',['http://doc.qt.io/qt-5/qfiledialog-obsolete.html#nameFilterDetailsVisible-prop',0,'QFileDialog']]],
  ['namefilterdisables',['nameFilterDisables',['http://doc.qt.io/qt-5/qfilesystemmodel.html#nameFilterDisables-prop',0,'QFileSystemModel']]],
  ['namefilters',['nameFilters',['../class_q_path_edit.html#a2c11672712401b2378603f1dd1b39714',1,'QPathEdit']]],
  ['nameserver',['nameserver',['http://doc.qt.io/qt-5/qdnslookup.html#nameserver-prop',0,'QDnsLookup']]],
  ['namespaceprocessing',['namespaceProcessing',['http://doc.qt.io/qt-5/qxmlstreamreader.html#namespaceProcessing-prop',0,'QXmlStreamReader']]],
  ['nativemenubar',['nativeMenuBar',['http://doc.qt.io/qt-5/qmenubar.html#nativeMenuBar-prop',0,'QMenuBar']]],
  ['nativeorientation',['nativeOrientation',['http://doc.qt.io/qt-5/qscreen.html#nativeOrientation-prop',0,'QScreen']]],
  ['navigationbarvisible',['navigationBarVisible',['http://doc.qt.io/qt-5/qcalendarwidget.html#navigationBarVisible-prop',0,'QCalendarWidget']]],
  ['networkaccessible',['networkAccessible',['http://doc.qt.io/qt-5/qnetworkaccessmanager.html#networkAccessible-prop',0,'QNetworkAccessManager']]],
  ['normalgeometry',['normalGeometry',['http://doc.qt.io/qt-5/qwidget.html#normalGeometry-prop',0,'QWidget']]],
  ['notation',['notation',['http://doc.qt.io/qt-5/qdoublevalidator.html#notation-prop',0,'QDoubleValidator']]],
  ['notchesvisible',['notchesVisible',['http://doc.qt.io/qt-5/qdial.html#notchesVisible-prop',0,'QDial']]],
  ['notchsize',['notchSize',['http://doc.qt.io/qt-5/qdial.html#notchSize-prop',0,'QDial']]],
  ['notchtarget',['notchTarget',['http://doc.qt.io/qt-5/qdial.html#notchTarget-prop',0,'QDial']]]
];
