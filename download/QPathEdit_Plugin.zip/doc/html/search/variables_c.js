var searchData=
[
  ['numberflags',['NumberFlags',['http://doc.qt.io/qt-5/qtextstream.html#NumberFlag-enum',0,'QTextStream']]],
  ['numberoptions',['NumberOptions',['http://doc.qt.io/qt-5/qlocale.html#NumberOption-enum',0,'QLocale']]]
];
