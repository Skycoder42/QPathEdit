var searchData=
[
  ['y',['y',['http://doc.qt.io/qt-5/qwindow.html#y-prop',0,'QWindow::y()'],['http://doc.qt.io/qt-5/qquickitem.html#y-prop',0,'QQuickItem::y()'],['http://doc.qt.io/qt-5/qaccelerometerreading.html#y-prop',0,'QAccelerometerReading::y()'],['http://doc.qt.io/qt-5/qgyroscopereading.html#y-prop',0,'QGyroscopeReading::y()'],['http://doc.qt.io/qt-5/qmagnetometerreading.html#y-prop',0,'QMagnetometerReading::y()'],['http://doc.qt.io/qt-5/qrotationreading.html#y-prop',0,'QRotationReading::y()'],['http://doc.qt.io/qt-5/qgraphicsobject.html#y-prop',0,'QGraphicsObject::y()'],['http://doc.qt.io/qt-5/qwidget.html#y-prop',0,'QWidget::y()']]],
  ['yoffset',['yOffset',['http://doc.qt.io/qt-5/qgraphicsdropshadoweffect.html#yOffset-prop',0,'QGraphicsDropShadowEffect']]],
  ['yrotation',['yRotation',['http://doc.qt.io/qt-5/qtiltreading.html#yRotation-prop',0,'QTiltReading']]],
  ['yscale',['yScale',['http://doc.qt.io/qt-5/qgraphicsscale.html#yScale-prop',0,'QGraphicsScale']]]
];
