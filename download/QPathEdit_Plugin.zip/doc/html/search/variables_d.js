var searchData=
[
  ['offsetdatalist',['OffsetDataList',['http://doc.qt.io/qt-5/qtimezone.html#OffsetDataList-typedef',0,'QTimeZone']]],
  ['openglfeatures',['OpenGLFeatures',['http://doc.qt.io/qt-5/qopenglfunctions.html#OpenGLFeature-enum',0,'QOpenGLFunctions']]],
  ['openmode',['OpenMode',['http://doc.qt.io/qt-5/qiodevice.html#OpenModeFlag-enum',0,'QIODevice']]],
  ['optimizationflags',['OptimizationFlags',['http://doc.qt.io/qt-5/qgraphicsview.html#OptimizationFlag-enum',0,'QGraphicsView']]],
  ['options',['Options',['http://doc.qt.io/qt-5/qfiledialog.html#Option-enum',0,'QFileDialog::Options()'],['http://doc.qt.io/qt-5/qfileiconprovider.html#Option-enum',0,'QFileIconProvider::Options()']]],
  ['orientations',['Orientations',['http://doc.qt.io/qt-5/qt.html#Orientation-enum',0,'Qt']]]
];
