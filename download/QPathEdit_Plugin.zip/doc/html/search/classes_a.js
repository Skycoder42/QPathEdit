var searchData=
[
  ['package',['Package',['http://doc.qt.io/qt-5/qml-package.html',0,'']]],
  ['paintcontext',['PaintContext',['http://doc.qt.io/qt-5/qabstracttextdocumentlayout-paintcontext.html',0,'QAbstractTextDocumentLayout']]],
  ['pixmapfragment',['PixmapFragment',['http://doc.qt.io/qt-5/qpainter-pixmapfragment.html',0,'QPainter']]],
  ['point2d',['Point2D',['http://doc.qt.io/qt-5/qsggeometry-point2d.html',0,'QSGGeometry']]]
];
