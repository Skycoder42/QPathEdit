var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwxyz~",
  1: "abcefikmnopqrstuvw",
  2: "q",
  3: "abcdefghijklmnopqrstuvwxyz~",
  4: "abcdefghiklmnoprstuvw",
  5: "ps",
  6: "aejns",
  7: "abcdefghiklmnopqrstuvwxyz"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties"
};

