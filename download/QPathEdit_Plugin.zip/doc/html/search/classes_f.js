var searchData=
[
  ['updatepaintnodedata',['UpdatePaintNodeData',['http://doc.qt.io/qt-5/qquickitem-updatepaintnodedata.html',0,'QQuickItem']]]
];
