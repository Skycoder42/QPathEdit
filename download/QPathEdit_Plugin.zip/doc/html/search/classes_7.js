var searchData=
[
  ['margins',['Margins',['http://doc.qt.io/qt-5/qpagedpaintdevice-margins.html',0,'QPagedPaintDevice']]],
  ['memorylayout',['MemoryLayout',['http://doc.qt.io/qt-5/qlist-memorylayout.html',0,'QList']]]
];
