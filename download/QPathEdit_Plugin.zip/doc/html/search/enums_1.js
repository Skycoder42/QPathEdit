var searchData=
[
  ['style',['Style',['../class_q_path_edit.html#a5f772e9405220fd9cbace22ccd7e38b5',1,'QPathEdit']]]
];
