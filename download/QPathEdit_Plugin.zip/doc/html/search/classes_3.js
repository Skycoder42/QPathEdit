var searchData=
[
  ['element',['Element',['http://doc.qt.io/qt-5/qpainterpath-element.html',0,'QPainterPath']]],
  ['extraselection',['ExtraSelection',['http://doc.qt.io/qt-5/qtextedit-extraselection.html',0,'QTextEdit']]]
];
