var searchData=
[
  ['null',['Null',['http://doc.qt.io/qt-5/qstring-null.html',0,'QString']]]
];
