var searchData=
[
  ['geocodingfeatures',['GeocodingFeatures',['http://doc.qt.io/qt-5/qgeoserviceprovider.html#GeocodingFeature-enum',0,'QGeoServiceProvider']]],
  ['gestureflags',['GestureFlags',['http://doc.qt.io/qt-5/qt.html#GestureFlag-enum',0,'Qt']]],
  ['glyphrunflags',['GlyphRunFlags',['http://doc.qt.io/qt-5/qglyphrun.html#GlyphRunFlag-enum',0,'QGlyphRun']]],
  ['graphicsitemflags',['GraphicsItemFlags',['http://doc.qt.io/qt-5/qgraphicsitem.html#GraphicsItemFlag-enum',0,'QGraphicsItem']]]
];
