var searchData=
[
  ['x',['x',['http://doc.qt.io/qt-5/qwindow.html#x-prop',0,'QWindow::x()'],['http://doc.qt.io/qt-5/qquickitem.html#x-prop',0,'QQuickItem::x()'],['http://doc.qt.io/qt-5/qaccelerometerreading.html#x-prop',0,'QAccelerometerReading::x()'],['http://doc.qt.io/qt-5/qgyroscopereading.html#x-prop',0,'QGyroscopeReading::x()'],['http://doc.qt.io/qt-5/qmagnetometerreading.html#x-prop',0,'QMagnetometerReading::x()'],['http://doc.qt.io/qt-5/qrotationreading.html#x-prop',0,'QRotationReading::x()'],['http://doc.qt.io/qt-5/qgraphicsobject.html#x-prop',0,'QGraphicsObject::x()'],['http://doc.qt.io/qt-5/qwidget.html#x-prop',0,'QWidget::x()']]],
  ['xoffset',['xOffset',['http://doc.qt.io/qt-5/qgraphicsdropshadoweffect.html#xOffset-prop',0,'QGraphicsDropShadowEffect']]],
  ['xrotation',['xRotation',['http://doc.qt.io/qt-5/qtiltreading.html#xRotation-prop',0,'QTiltReading']]],
  ['xscale',['xScale',['http://doc.qt.io/qt-5/qgraphicsscale.html#xScale-prop',0,'QGraphicsScale']]]
];
