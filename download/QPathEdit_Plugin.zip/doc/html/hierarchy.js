var hierarchy =
[
    [ "QObject", "http://doc.qt.io/qt-5/qobject.html", [
      [ "QWidget", "http://doc.qt.io/qt-5/qwidget.html", [
        [ "QPathEdit", "class_q_path_edit.html", null ]
      ] ]
    ] ],
    [ "QPaintDevice", "http://doc.qt.io/qt-5/qpaintdevice.html", [
      [ "QWidget", "http://doc.qt.io/qt-5/qwidget.html", null ]
    ] ]
];